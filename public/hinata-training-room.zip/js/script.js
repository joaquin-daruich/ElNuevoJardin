
let count = 0;
function nextScene() {
    const text = document.getElementById("text");
    if (count === 0) {
        text.innerText = "Hinata se sonroja y baja la mirada...";
    } else if (count === 1) {
        text.innerText = "Ella se acerca lentamente, parece que quiere decirte algo.";
    } else if (count === 2) {
        text.innerText = "¿Querés desbloquear el final secreto? ;)";
    } else {
        text.innerText = "Fin del demo. Próximamente más contenido...";
    }
    count++;
}
